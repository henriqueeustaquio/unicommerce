package br.com.alura.unicommerce.simulando;

public class CadastroDadaos {

	public static void main(String[] args) {

	}

}
