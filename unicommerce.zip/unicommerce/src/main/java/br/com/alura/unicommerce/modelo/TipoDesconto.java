package br.com.alura.unicommerce.modelo;

public enum TipoDesconto {

	FIDELIDADE, 
	NENHUM
}
