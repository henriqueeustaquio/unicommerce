package br.com.alura.unicommerce.dao;

public class EnderecoDao {

	/*
	 * private EntityManager em;
	 * 
	 * public EnderecoDao(EntityManager em) { this.em = em; }
	 * 
	 * public void cadastrar(Endereco endereco) { this.em.persist(endereco); }
	 * 
	 * public void atualizar(Endereco endereco) { this.em.merge(endereco); }
	 * 
	 * public void remover(Endereco endereco) { endereco = em.merge(endereco);
	 * this.em.remove(endereco); }
	 * 
	 * public Endereco buscarPorId(Long id) { return em.find(Endereco.class, id); }
	 * 
	 * public List<Endereco> buscarTodos() { String jpql =
	 * "SELECT p FROM Endereco p"; return em.createQuery(jpql,
	 * Endereco.class).getResultList(); }
	 */
}
