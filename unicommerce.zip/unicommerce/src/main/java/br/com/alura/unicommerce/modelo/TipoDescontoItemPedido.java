package br.com.alura.unicommerce.modelo;

public enum TipoDescontoItemPedido {

	QUANTIDADE, 
	PROMOCAO, 
	NENHUM
}
